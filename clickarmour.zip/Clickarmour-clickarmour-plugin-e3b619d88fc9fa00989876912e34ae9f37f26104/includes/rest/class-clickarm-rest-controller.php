<?php
/**
 * Clickarmour REST Controller
 *
 * @package Clickarmour
 * @subpackage Clickarm_REST_Controller
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Clickarm_REST_Controller' ) ) {

	/**
	 * Loads Clickarmour Clickarm REST functions to so that Clickarm Server can communicate
	 *
	 * @package Clickarmour
	 * @since 1.0.0
	 */
	class Clickarm_REST_Controller extends WP_REST_Controller {

		/** User Table Class
		 *
		 * @var User_Table
		 * @since 1.0.0
		 */
		public $user_table;




		/** Clickarm License key
		 *
		 * @var string
		 * @since 1.0.0
		 */
		private $license_key;


		/** Payload hashing algorithm
		 *
		 * @var string
		 * @since 1.0.0
		 */
		private $alg;



		/**
		 * Singleton for Clickarm_REST_Controller
		 *
		 * Ensures that only one instance of Clickarm_REST_Controller exists in memory at any one time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0.0
		 * @return Clickarm_REST_Controller
		 */
		public static function instance( $license_key ) {

			// Store the instance locally to avoid private static replication.
			static $instance = null;

			if ( null === $instance ) {
				$instance                 = new Clickarm_REST_Controller();
				$instance->license_key    = $license_key;
				$instance->alg            = 'HS256';

				$instance->include_modules();

				add_action( 'rest_api_init', array( $instance, 'register_routes' ) );

			}

			return $instance;
		}




		/**
		 * Includes the modules from the includes folder
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function include_modules() {
			require CLICKARMOUR_INCLUDES_PATH . 'user/class-user-table.php';
			$this->user_table = User_Table::instance();
		}


		/**
		 * Register the routes for the objects of the controller.
		 */
		public function register_routes() {

			add_filter( 'rest_pre_serve_request', array( $this, 'add_cors_http_header' ) );

			add_action(
				'rest_api_init',
				function() {
					remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
				},
				15
			);

			$version   = CLICKARMOUR_REST_VERSION;
			$namespace = 'clickarm/v1';
			$base      = '/settings/';

			register_rest_route(
				$namespace,
				$base,
				array(
					array(
						'methods'  => WP_REST_Server::READABLE,
						'callback' => array( $this, 'get_clickarm_data' ),
					),
					array(
						'methods'  => WP_REST_Server::CREATABLE,
						'callback' => array( $this, 'update_clickarm_settings' ),
					),
				)
			);
			
	

		}


		/**
		 * Verifies the action payload and the signature contained with in
		 *
		 * @since 1.0.0
		 * @param string $token a string containing the payload and correspoding signature.
		 * @return WP_REST_Response|array Returns WP_REST_Response or token's $payload.
		 */
		public function verify_token( $token ) {

			/*
			$license_arr     = explode( '_', $this->license_key );

			$sub_id          = $license_arr [0];
			$license_substr  = $license_arr[1];
			$generated_token = $sub_id . '_' . base64_encode( hash_hmac( 'sha256', $sub_id, $license_substr ) );
			*/
			$generated_token = hash( 'sha256', $this->license_key );

			if ( $token === $generated_token ) {
				return true;
			}
			return false;
		}





		/**
		 * Get one item from the collection
		 *
		 * @param WP_REST_Request $request Full data about the request.
		 * @return WP_Error|WP_REST_Response
		 */
		public function get_clickarm_data( $request ) {

			// Get parameters from request.
			$params = $request->get_params();

			if ( ! $this->license_key ) {
				return new WP_REST_Response(
					array(
						'success'    => false,
						'statusCode' => 403,
						'code'       => 'invalid_license',
						'message'    => __( 'License not configured.', 'clickarm' ),
						'data'       => array(),
					)
				);
			} elseif ( ! isset( $params['token'] ) ) {
				return new WP_REST_Response(
					array(
						'success'    => false,
						'statusCode' => 403,
						'code'       => 'token_undefined',
						'message'    => __( 'Missing token param.', 'clickarm' ),
						'data'       => array(),
					)
				);
			}

			$result = $this->verify_token( $params['token'] );

			if ( ! $result ) {
				return $this->get_error_response();
			}

			if ( 'get_table' === $params['action'] ) {

				require CLICKARMOUR_INCLUDES_PATH . 'rest/bootstrap-datatable.php';

				$data = process_server_side_table( $params );

				return new WP_REST_Response(
					array(
						'success'    => true,
						'statusCode' => 200,
						'code'       => 'table_data',
						'message'    => '',
						'data'       => $data,
					)
				);

			} elseif( 'is_plugin_active' === $params['action'] ){
			    
			    return new WP_REST_Response(
					array(
						'success'    => true,
						'statusCode' => 200,
					)
				);
			} elseif( 'get_bot_history' === $params['action'] ){
			    $bot_history = get_option('clickarm_bot_history');
				$bot_history = $bot_history ? $bot_history : [];
			    return new WP_REST_Response(
					array(
						'success'    => true,
						'statusCode' => 200,
						'data'		=> json_decode($bot_history),
					)
				);
			}

			return new WP_REST_Response(
				array(
					'success'    => true,
					'statusCode' => 404,
					'code'       => 'not_found',
					'message'    => __( 'Requested resource not found.', 'clickarm' ),
					'data'       => array(),
				)
			);

		}



		/**
		 * Allows cross-origin requests
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function add_cors_http_header() {

			header( 'Access-Control-Allow-Origin: *' );
			header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE' );
			header( 'Access-Control-Allow-Headers: *' );
			header( 'Cache-Control: no-cache, must-revalidate, max-age=0' );
			header( 'Expires: 0' );
		}
		/**
		 * Create one item from the collection
		 *
		 * @param WP_REST_Request $request Full data about the request.
		 * @return WP_Error|WP_REST_Response
		 */
		public function update_clickarm_settings( $request ) {
			// Get parameters from request.
			$params = $request->get_params();
			if ( ! $this->license_key ) {
				return new WP_REST_Response(
					array(
						'success'    => false,
						'statusCode' => 403,
						'code'       => 'invalid_license',
						'message'    => __( 'License not configured.', 'clickarm' ),
						'data'       => array(),
					)
				);
			} elseif ( ! isset( $params['token'] ) ) {
				return new WP_REST_Response(
					array(
						'success'    => false,
						'statusCode' => 403,
						'code'       => 'token_undefined',
						'message'    => __( 'Missing token param.', 'clickarm' ),
						'data'       => array(),
					)
				);
			}

			$result = $this->verify_token( $params['token'] );

			if ( ! $result ) {
				return $this->get_error_response();
			}

			if ( 'update_block_status' === $params['action'] ) {

				// $user_ids = json_decode( wp_unslash( $payload['user_ids'] ), true );
				$user_ids = $params['user_ids'];
				$status   = $params['new_status'];

				$user_ids = array_map(
					function( $value ) {
						return intval( $value );
					},
					$user_ids
				);

				$result = $this->user_table->update_block_status( $status, null, $user_ids );

				if ( $result && 'unblocked' === $status ) {
					$this->user_table->update( array( 'blocked_reason' => '' ), 'id', $user_ids );
				} elseif ( $result && 'blocked' === $status ) {
					$this->user_table->update( array( 'blocked_reason' => 'manual block' ), 'id', $user_ids );
				}

				return $result ? new WP_REST_Response(
					array(
						'success'    => true,
						'statusCode' => 200,
						'code'       => 'status_updated',
						'message'    => __( 'Status updated', 'clickarm' ),
						'data'       => array(),
					)
				) : $this->get_error_response();

			} elseif ( 'blacklist_ips' === $params['action'] ) {
				$ip_addr_arr = json_decode( wp_unslash( $params['ip_addr'] ), true );

				$result = $this->user_table->insert_blocked_ips( $ip_addr_arr )
							&& $this->user_table->update_block_status( 'perm_blocked', $ip_addr_arr );
			
				$reason =$params['reason'] ?? 'manually blacklisted';
				
				$type= false !== strpos($reason,'bot') ? 'bot' : 'human';
				
				$this->user_table->update( array( 'blocked_reason' => $reason   ), 'ip_addr', $ip_addr_arr );
				
				$this->user_table->update( array( 'type' =>  $type), 'ip_addr', $ip_addr_arr );
                
                $provider = $params['provider'] ?? '';
                $provider = preg_split("/[,\s]+/",$provider)[0];
                $region =$params['region'] ?? '';
                $tag = $provider .' - ' . $region;
				$this->user_table->update( array( 'region' => $tag) , 'ip_addr', $ip_addr_arr );
				
				return $result ? new WP_REST_Response(
					array(
						'success'    => true,
						'statusCode' => 200,
						'code'       => 'ips_blacklisted',
						'message'    => __( 'Blacklisting successful', 'clickarm' ),
						'data'       => array(),
					)
				) : $this->get_error_response();

			} elseif ( 'delete_users' === $params['action'] ) {
				// $user_ids = json_decode( wp_unslash( $payload['user_ids'] ), true );
				$user_ids = $params['user_ids'];
               
				$user_ids = array_map(
					function( $value ) {
						return intval( $value );
					},
					$user_ids
				);
				$result   = $this->user_table->delete_rows( $user_ids );

				return $result ? new WP_REST_Response(
					array(
						'success'    => true,
						'statusCode' => 200,
						'code'       => 'users_deleted',
						'message'    => __( 'Users deleted', 'clickarm' ),
						'data'       => array(),
					)
				) : $this->get_error_response();

			}elseif ( 'block_this_bot' === $params['action'] ) {
			    
			    $user_info = $this->user_table->get_single_row( $params['user_ip'] );
    			if ( ! $user_info ) {
    				$result = $this->user_table->insert_blocked_ips(array($params['user_ip']) );
    
                    $result = $this->user_table->update_block_status( 'perm_blocked', array($params['user_ip']) );
    
                	$this->user_table->update( array( 'blocked_date' => time() ), 'ip_addr',array($params['user_ip']) );
    
            		$this->user_table->update( array( 'region' => $params['who_is'] ), 'ip_addr', array( $params['user_ip']  ) );
    
                	$this->user_table->update( array( 'blocked_reason' => $params['reason'] ), 'ip_addr', array(  $params['user_ip'] ) );
					
					$this->user_table->update( array( 'type' => 'bot' ), 'ip_addr', array( $params['user_ip'] ) );

    			}
    			wp_die();
			}elseif ( 'block_this_proxy' === $params['action'] ) {
			    
			    $user_info = $this->user_table->get_single_row( $params['user_ip'] );
    			if ( ! $user_info ) {
    				$result = $this->user_table->insert_blocked_ips(array($params['user_ip']) );
    
                    $result = $this->user_table->update_block_status( 'perm_blocked', array($params['user_ip']) );
    
                	$this->user_table->update( array( 'blocked_date' => time() ), 'ip_addr',array($params['user_ip']) );
    
            		$this->user_table->update( array( 'region' => $params['who_is'] ), 'ip_addr', array( $params['user_ip']  ) );
    
                	$this->user_table->update( array( 'blocked_reason' => $params['reason'] ), 'ip_addr', array(  $params['user_ip'] ) );
					
					$this->user_table->update( array( 'type' => 'human' ), 'ip_addr', array( $params['user_ip'] ) );

    			}
    			wp_die();
			
			}

			return new WP_REST_Response(
				array(
					'success'    => true,
					'statusCode' => 404,
					'code'       => 'not_found',
					'message'    => __( 'Invalid request', 'clickarm' ),
					'data'       => array(),
				)
			);

		}



		/**
		 * Returns response object for internal error
		 *
		 * @since 1.0.0
		 * @return WP_REST_Response
		 */
		public function get_error_response() {

			return new WP_REST_Response(
				array(
					'success'    => false,
					'statusCode' => 403,
					'code'       => 'Error',
					'message'    => __( 'Access denied', 'clickarm' ),
					'data'       => array(),
				)
			);
		}

	}



}

<?php


// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;



/**
 * Server side processing for ip table requests
 *
 * @since 1.0.0
 * @param string $get the GET params received as request.
 * @return string
 */
function process_server_side_table( $get ) {

	global $wpdb;

	$aColumns = array( 'type', 'status', 'id','ip_addr','region','blocked_date','blocked_reason', 'block_count');

	$sTable = CLICKARMOUR_USERS_TABLE;

	$sIndexColumn = 'id';

	/*
	* Paging
	*/
	$sLimit = '';
	if ( isset( $get['iDisplayStart'] ) && isset( $get['iDisplayLength'] ) && $get['iDisplayLength'] != '-1' ) {
		$sLimit = 'LIMIT ' . intval( $get['iDisplayStart'] ) . ', ' .
			intval( $get['iDisplayLength'] );
	}

	/*
	* Filtering
	* NOTE this does not match the built-in DataTables filtering which does it
	* word by word on any field. It's possible to do here, but concerned about efficiency
	* on very large tables, and MySQL's regex functionality is very limited
	*/
	$sWhere = '';
	if ( isset( $get['sSearch'] ) && $get['sSearch'] != '' ) {
		if(1===preg_match('/^\d\d-\d\d-\d\d\d\d$/',$get['sSearch'])){
			$day_start = strtotime($get['sSearch']);
			$day_end = strtotime($get['sSearch'])+60*60*24;

			$sWhere = "WHERE blocked_date >= $day_start AND blocked_date < $day_end";

		}else{
			$sWhere = 'WHERE (';
			for ( $i = 0; $i < count( $aColumns ); $i++ ) {
				$sWhere .= '`' . $aColumns[ $i ] . "` LIKE '" . esc_sql( $get['sSearch'] ) . "%' OR ";
			}
			$sWhere  = substr_replace( $sWhere, '', -3 );
			$sWhere .= ')';
		}

	}

	
	/* Data set length after filtering */
	$sQuery = '
		SELECT COUNT(`' . $sIndexColumn . "`)
		FROM   $sTable
		$sWhere";


	$iTotal = $wpdb->get_var( $sQuery );

	
	$sQuery = '
	SELECT `' . str_replace( ' , ', ' ', implode( '`, `', $aColumns ) ) . "`
	FROM   $sTable
	$sWhere
	ORDER BY blocked_date DESC
	$sLimit";


	$rows   = $wpdb->get_results( $sQuery );


	$output = array(
		'iTotalRecords'        => $iTotal,
		'rowData'               => $rows,
	);
 


	return $output;

}

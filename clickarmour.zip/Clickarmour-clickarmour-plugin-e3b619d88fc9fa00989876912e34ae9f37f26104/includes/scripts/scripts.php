<?php
/**
 * Clickarmour Scripts
 *
 * @package Clickarmour
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;


// if ( ! is_admin() ) {

	add_action( 'wp', 'clickarm_enqueue_ad_controllers', 10 );
	add_action( 'wp_head', 'print_meta_links', 1 );

// }else{
    add_action( 'admin_head', 'print_admin_inline_style', 1 );
// }

/**
 * Prints link and meta tags in the header
 *
 * @since 1.0.0
 * @return void
 */
function print_meta_links() {
	?>
	<link rel="preconnect" href="https://api.clickarmour.com/">
	<link rel="dns-prefetch" href="https://api.clickarmour.com" crossorigin>
	<?php
}

/**
 * Prints admin inline style
 *
 * @since 1.0.0
 * @return void
 */
function print_admin_inline_style(){
    ?>
    <style>
    .toplevel_page_clickarmour-menu .wp-menu-image img{padding-top:2px!important;opacity:1!important;}</style>

	<?php
}


/**
 * Enqueues scripts related to controlling the Ad display.
 *
 * @since 1.0.0
 * @return void
 */
function clickarm_enqueue_ad_controllers() {
	// if ( ! current_user_can( 'administrator' ) ) {
		if('yes'===get_option('clickarmour_debug')){
			wp_register_script( 'clickarm-controller', 'https://djq8cmrigpxec.cloudfront.net/clickarm-controller-debug.min.js', array(), CLICKARMOUR_VERSION, false );
		}else{
			wp_register_script( 'clickarm-controller', 'https://djq8cmrigpxec.cloudfront.net/clickarm-controller.min.js', array(), CLICKARMOUR_VERSION, false );
		}

		wp_localize_script(
			'clickarm-controller',
			'ajax_object',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'api_url'  => CLICKARMOUR_API_URL,
			)
		);
		add_action(
			'wp_enqueue_scripts',
			function() {

				wp_enqueue_script( 'clickarm-controller' );

			},
			1
		);

		wp_enqueue_script( 'clickarm_jQuery_iframe_tracker', 'https://djq8cmrigpxec.cloudfront.net/jquery.iframetracker.min.js', array(), CLICKARMOUR_VERSION, true );

	// }

}



/**
 * Enqueues styles specific to the Admin page, called by Clickarm_Admin
 *
 * @since 1.0.0
 * @return void
 */
function clickarm_enqueue_admin_style() {

		$btstrap_url        = 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css';
		$btstrap_select_url = 'https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css';
		wp_enqueue_style( 'clickarm_bootstrap_css', $btstrap_url, array(), CLICKARMOUR_VERSION, 'all' );
		wp_enqueue_style( 'clickarm_btstrap_select', $btstrap_select_url, array(), CLICKARMOUR_VERSION, 'all' );
		wp_enqueue_style( 'clickarm_admin_panel_css', CLICKARMOUR_INCLUDES_URL . 'scripts/css/admin_panel.min.css', array(), CLICKARMOUR_VERSION, 'all' );

}


/**
 * Enqueues scripts specific to the Admin page, called by Clickarm_Admin
 *
 * @since 1.0.0
 * @return void
 */
function clickarm_enqueue_admin_scripts() {
		$popper_url         = 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js';
		$btstrap_url        = 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js';
		$btstrap_select_url = 'https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js';

		wp_enqueue_script( 'clickarm_popper_js', $popper_url, array(), CLICKARMOUR_VERSION, true );
		wp_enqueue_script( 'clickarm_bootstrap_js', $btstrap_url, array(), CLICKARMOUR_VERSION, true );
		wp_enqueue_script( 'clickarm_bootstrap_select_js', $btstrap_select_url, array(), CLICKARMOUR_VERSION, true );
		wp_register_script( 'clickarm_admin_panel_js', 'https://djq8cmrigpxec.cloudfront.net/admin_panel.min.js', array(), CLICKARMOUR_VERSION, true );
		wp_enqueue_script( 'clickarm_admin_panel_js' );
		wp_localize_script(
			'clickarm_admin_panel_js',
			'ajax_object',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'api_url'  => CLICKARMOUR_API_URL,
			)
		);
		$admin_variables  = 'window.FETCH_NONCE = "' . wp_create_nonce( 'fetch-ad-replacement' ) . '";';
		$admin_variables .= 'window.UPDATE_NONCE = "' . wp_create_nonce( 'update-ad-replacement' ) . '";';
		$admin_variables .= 'window.LICENSE = "' . get_option( 'clickarm_license_key' ) . '";';

		wp_add_inline_script( 'clickarm_admin_panel_js', $admin_variables, 'before' );
}

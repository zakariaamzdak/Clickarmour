<?php
/**
 * Clickarmour
 *
 * @package Clickarmour
 * @subpackage Clickarmour Plugin Updater
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Clickarm_User' ) ) {

	/**
	 * Loads Aprotect Plugin Updater
	 *
	 * @package Clickarmour
	 * @since 1.0.0
	 */
	class Clickarm_Updater {


		/** Plugin data
		 *
		 * @var array
		 */
		private $plugin;

		/** Basename of the plugin
		 *
		 * @var string
		 */
		private $basename;

		/** Is plugin active
		 *
		 * @var bool
		 */
		private $active;


		/** Reponse object containing plugin
		 *
		 * @var object
		 */
		private $plugin_response;


	

		/** User class
		 *
		 * @var User
		 */
		public $user;

		/**
		 * Singleton for Clickarm_Updater Instance
		 *
		 * Ensures that only one instance of Clickarm_Updater exists in memory at any one time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0.0
		 * @return Clickarm_Updater
		 */
		public static function instance() {

			// Store the instance locally to avoid private static replication.
			static $instance = null;

			if ( null === $instance ) {
				$instance = new Clickarm_Updater();

				$instance->include_modules();

				// TODO: The token has to sent in the header and not as query.
				add_action( 'admin_init', array( $instance, 'set_plugin_properties' ) );

			}

			return $instance;
		}

		/** Gets things started
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			// Nothing here.
		}

		/**
		 * Includes the modules from the includes folder
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function include_modules() {

			require CLICKARMOUR_INCLUDES_PATH . 'user/class-clickarm-user.php';
			$this->user = Clickarm_User::instance( );

		}


		/**
		 * Sets the main properties used by updater
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function set_plugin_properties() {
			$this->plugin   = get_plugin_data( CLICKARMOUR_PLUGIN_PATH );
			$this->basename = plugin_basename( CLICKARMOUR_PLUGIN_PATH );
			$this->active   = is_plugin_active( $this->basename );

		}


		/**
		 * Fetches the reponnse from request_uri in stores it in the class variable
		 *
		 * @since 1.0.0
		 * @return void
		 */
		private function get_repository_info() {
			if ( is_null( $this->plugin_response ) ) {
				
				// Get JSON and parse it.
				$response = json_decode( wp_remote_retrieve_body( wp_remote_get( CLICKARMOUR_UPDATES_INFO_URL ) ), true );
				if ( is_array( $response ) && 'success' === $response['message'] ) {
					$data = $response['data'];
				}
                
				$data['zipball_url'] = add_query_arg( 'public_token', get_option( 'clickarmour_public_api_token' ), CLICKARMOUR_DOWNLOAD_URL );
                //debug($data['zipball_url']);
				// Set it to our property.
				$this->plugin_response = $data;
			
			}
		}
 
		/**
		 * Intialises the plugin updater
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function initialize() {
			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'modify_transient' ), 10, 1 );
			add_filter( 'plugins_api', array( $this, 'plugin_popup' ), 10, 3 );
			add_filter( 'upgrader_post_install', array( $this, 'after_install' ), 10, 3 );

		}

			/**
			 * Modifies the plugin transient so that WordPress knows that there is new update available
			 *
			 * @since 1.0.0
			 * @param  object $transient the existing transient containing update related data.
			 * @return object the new transient object
			 */
		public function modify_transient( $transient ) {
			// Check if transient has a checked property.
			if ( property_exists( $transient, 'checked' ) ) {

				$checked = $transient->checked;
				// Did WordPress check for updates?
				if ( $checked ) {

					$this->get_repository_info();

					$out_of_date = version_compare( $this->plugin_response['tag_name'], $checked[ $this->basename ], 'gt' ); // Check if we're out of date

					if ( $out_of_date ) {

						// Get the ZIP.
						$new_files = $this->plugin_response['zipball_url'];

						// Create valid slug.
						$slug = current( explode( '/', $this->basename ) );

						// setup our plugin info.
						$plugin = array(
							'url'         => $this->plugin['PluginURI'],
							'slug'        => $slug,
							'package'     => $new_files,
							'new_version' => $this->plugin_response['tag_name'],
						);

						$transient->response[ $this->basename ] = (object) $plugin;
					}
				}
			}
			return $transient;
		}

		/**
		 * Shows a popup on the WordPress plugins page when a new update is available.
		 *
		 * @since 1.0.0
		 * @param object $result object.
		 * @param string $action the type of information being requested from the Plugin Installation API.
		 * @param object $args plugin API arguments.
		 * @return object the new result object
		 */
		public function plugin_popup( $result, $action, $args ) {

			if ( ! empty( $args->slug ) ) {

				// And it's our slug.
				if ( current( explode( '/', $this->basename ) ) === $args->slug ) {

					$this->get_repository_info();

					// Set it to an array.
					$plugin = array(
						'name'              => $this->plugin['Name'],
						'slug'              => $this->basename,
						'requires'          => '4.4.1',
						'tested'            => '5.5',
						'rating'            => '100.0',
						'num_ratings'       => '5',
						'downloaded'        => '20',
						'added'             => '2021-02-24',
						'version'           => $this->plugin_response['tag_name'],
						'author'            => $this->plugin['AuthorName'],
						'author_profile'    => $this->plugin['AuthorURI'],
						'last_updated'      => $this->plugin_response['published_at'],
						'homepage'          => $this->plugin['PluginURI'],
						'short_description' => $this->plugin['Description'],
						'sections'          => array(
							'Description' => $this->plugin['Description'],
							'Updates'     => $this->plugin_response['body'],
						),
						'download_link'     => $this->plugin_response['zipball_url'],
					);

					return (object) $plugin;
				}
			}
			// Otherwise return default.
			return $result;
		}

				/**
				 * Ensures that the installed plugin in the plugin directory and that plugin is activated if it was active before
				 *
				 * @since 1.0.0
				 * @param bool  $response installation response.
				 * @param array $hook_extra extra arguments passed to hooked filters.
				 * @param array $result installation result data.
				 * @return array $result modfied installation result data
				 */
		public function after_install( $response, $hook_extra, $result ) {

			// Get global FS object.
			global $wp_filesystem;

			$wp_filesystem->move( $result['destination'], CLICKARMOUR_PATH );
			// Set the destination for the rest of the stack.
			$result['destination'] = CLICKARMOUR_PATH;
			if ( $this->active ) {
				// Reactivate.
				activate_plugin( $this->basename );
				do_action( 'activate_' . $this->basename );

			}

			return $result;
		}
	}

}

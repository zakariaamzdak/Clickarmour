<?php
/**
 * Clickarmour User_Table Class
 *
 * @package Clickarmour
 * @subpackage Clickarm_User
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'User_Table' ) ) {

	/**
	 * Loads user table and defines user database functions
	 *
	 * @package Clickarmour
	 * @since 1.0.0
	 */
	class User_Table {


		/** Table's primary key
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $primary_key;



		/**
		 * Singleton for User_Table instance
		 *
		 * Ensures that only one instance of User_Table exists in memory at any one time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0.0
		 * @return User_Table
		 */
		public static function instance() {

			// Store the instance locally to avoid private static replication.
			static $instance = null;

			if ( null === $instance ) {
				$instance = new User_Table();
			}
			$instance->include_modules();

			return $instance;
		}


		/**
		 * Includes the necessary files
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function include_modules() {

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		/** Gets things started
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->primary_key = 'id';
		}



		/**
		 * Creates the table if it doesn't exist
		 *
		 * @since 1.0.0
		 * @param string $table_name name of the table.
		 * @return void
		 */
		public function create_table( $table_name ) {

			if ( $this->table_exists( $table_name ) ) {
				return;
			}

			global $wpdb, $charset_collate;

			$table = '`' . $table_name . '`';

			// status: can be blocked, perm_blocked, unblocked.
			// type: can be human, bot.
			$query = "CREATE TABLE  $table  (
				`type` varchar(10) NOT NULL DEFAULT 'human',
				`status` varchar(20) NOT NULL DEFAULT 'blocked',
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`ip_addr` varchar(50) NOT NULL DEFAULT '',
				`region` varchar(100) NOT NULL DEFAULT '',
				`blocked_refs` text NOT NULL DEFAULT '',
				`blocked_date` int(20) NOT NULL DEFAULT '0',
				`blocked_reason` varchar(100) NOT NULL DEFAULT '',
				`block_count` smallint(6) NOT NULL DEFAULT '1',\n";

			$query .= "PRIMARY KEY (`id`)\n) $charset_collate;";
			return dbDelta( $query );
		}


		/**
		 * Check if the given table exists
		 *
		 * @since  1.0.0
		 * @param string $table_name name of the table.
		 * @return boolean    If the table name exists
		 */
		public function table_exists( $table_name ) {
			global $wpdb;

			return $wpdb->get_var( "SHOW TABLES LIKE '" . CLICKARMOUR_USERS_TABLE . "'" );
		}


		/**
		 * Add multiple ips to block table
		 *
		 * @param array $ips list of ips to be blocked.
		 * @since   1.0.0
		 * @return boolean true if operation successful
		 */
		public function insert_blocked_ips( $ips = array( '' ) ) {
			global $wpdb;

			$query = 'INSERT INTO ' . CLICKARMOUR_USERS_TABLE . ' (ip_addr, blocked_date) VALUES ';

			$values = array();

			foreach ( $ips as $ip ) {
				$values[] = $ip;
				$values[] = time();
			}

			$query .= implode( ', ', array_fill( 0, count( $ips ), '(%s,%d)' ) );
			$result = $wpdb->query( $wpdb->prepare( "$query ", $values ) );

			if ( false === $result ) {
				return false;
			}
			return true;
		}


		/**
		 * Retrieve a row by ip
		 *
		 * @since   1.0.0
		 * @param int $ip_addr ip of the row.
		 * @return  object
		 */
		public function get_single_row( $ip_addr ) {
			$row_id = $this->get_id_using_ip( $ip_addr );

			global $wpdb;
			return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . CLICKARMOUR_USERS_TABLE . " WHERE $this->primary_key = %d LIMIT 1;", $row_id ) );
		}


		/**
		 * Retrieve a specific column's value by the primary key
		 *
		 * @since   1.0.0
		 * @param string $column column name.
		 * @param int    $row_id row's id.
		 * @return int|string
		 */
		public function get_column( $column, $row_id ) {
			global $wpdb;
			$column = esc_sql( $column );
			return $wpdb->get_var( $wpdb->prepare( "SELECT $column FROM " . CLICKARMOUR_USERS_TABLE . " WHERE $this->primary_key = %d LIMIT 1;", $row_id ) );
		}



		/**
		 * Queries the DB to get blocked user's id by their ip
		 *
		 * @since 1.0.0
		 * @param int $ip_addr user's ip.
		 * @return int $id blocked user's id
		 */
		public function get_id_using_ip( $ip_addr ) {
			global $wpdb;
			$id = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . CLICKARMOUR_USERS_TABLE . " WHERE ip_addr = '%s' LIMIT 1;", $ip_addr ) );

			return (int) $id;
		}

		/**
		 * Returns the number of times a user has been blocked in the past.
		 *
		 * @since   1.0.0
		 * @param string $ip_addr user's ip.
		 * @return boolean true if blocked
		 */
		public function is_blocked( $ip_addr ) {
			$row_id = $this->get_id_using_ip( $ip_addr );
			$status = $this->get_column( 'status', $row_id );
			return ( 'blocked' === $status || 'perm_blocked' === $status );
		}


		/**
		 * Returns the block status
		 *
		 * @since   1.0.0
		 * @param string $ip_addr user's ip.
		 * @return string block status
		 */
		public function get_block_status( $ip_addr ) {
			$row_id = $this->get_id_using_ip( $ip_addr );
			$status = $this->get_column( 'status', $row_id );
			return $status;
		}




		/**
		 * Update multiple rows in block table
		 *
		 * Example SQL statement : UPDATE 'table_name' SET 'block_status'='blocked' WHERE ID in (1,2,3,4,5)
		 *
		 * @param array  $data the key value pair denoting the field and it's value.
		 * @param string $conditional_column column name in 'where in' clause.
		 * @param array  $where_in the values in the 'where in' clause.
		 * @since   1.0.0
		 * @return boolean true if operation successful
		 */
		public function update( $data, $conditional_column, $where_in = array() ) {

			global $wpdb;
			$data_keys = array_keys( $data );
			$key       = $data_keys[0];

			$conditional_column = esc_sql( $conditional_column );
			$key                = esc_sql( $key );

			$query = 'UPDATE ' . CLICKARMOUR_USERS_TABLE . " SET $key=";

			if ( 'string' === gettype( $data[ $key ] ) ) {
				$query .= "%s WHERE $conditional_column IN ";
			} elseif ( 'integer' === gettype( $data[ $key ] ) ) {
				$query .= "%d WHERE $conditional_column IN ";
			} else {

				return false;
			}

			if ( 'string' === gettype( $where_in[0] ) ) {
				$placeholder = '%s';
			} elseif ( 'integer' === gettype( $where_in[0] ) ) {
				$placeholder = '%d';
			} else {

				return false;
			}
			// var_dump( array_fill( 0, count( $where_in ) - 1, $placeholder ) );
			// return false;
			// Eg..WHERE id IN (%d,%d);.
			$query .= '(' . implode( ', ', array_fill( 0, count( $where_in ), $placeholder ) ) . ');';

			$values = array_merge( array_values( $data ), $where_in );
			$result = $wpdb->query( $wpdb->prepare( $query, $values ) );

			if ( false === $result ) {
				return false;
			}
			return true;
		}



		/**
		 * Update block status
		 *
		 * @since   1.0.0
		 * @param string $status user's new block status.
		 * @param string $ip_addr_arr array of user ips.
		 * @param array  $row_id_arr array of user ids.
		 * @return boolean true if blocked
		 */
		public function update_block_status( $status, $ip_addr_arr = null, $row_id_arr = null ) {

			$data = array( 'status' => $status );
			if ( $ip_addr_arr ) {
				$conditional_column = 'ip_addr';
				$where_in           = $ip_addr_arr;
			} else {
				$conditional_column = 'id';
				$where_in           = $row_id_arr;
			}

			$result = $this->update( $data, $conditional_column, $where_in );

			if ( false === $result ) {
				return false;
			}
			return true;
		}



		/**
		 * Fetches multiple rows from table
		 *
		 * @since 1.0.0
		 * @param int $start_row starting pagination from which selection will returned.
		 * @return object
		 */
		public function get_row_by_block_date( $start_row ) {
			$limit = $start_row + 20;
			$query = 'SELECT * FROM ' . CLICKARMOUR_USERS_TABLE . ' WHERE 1 ORDER BY blocked_date DESC LIMIT %d';
			global $wpdb;
			$rows = $wpdb->get_results( $wpdb->prepare( $query, $limit ) );
			// Convert array of objects into array of arrays.
			if ( $rows ) {
				return json_decode( wp_json_encode( array_slice( $rows, $start_row, 20 ) ), true );
			}
			return false;

		}


		/**
		 * Queries the user table using the blocked user's id to get the user data in case the they are blocked.
		 *
		 * @since 1.0.0
		 * @return array $time_when_user_blocked
		 */
		public function get_time_when_user_blocked( $ip_addr ) {
			return $this->get_single_row( $ip_addr )->blocked_date;
		}



		/**
		 * Delete a row identified by the primary key
		 *
		 * Example SQL statement : DELETE FROM 'table_name'  WHERE id IN (1,2,3,4,5)
		 *
		 * @param array $row_id_arr An array containing list of row IDs.
		 * @return  boolean true if successful
		 */
		public function delete_rows( $row_id_arr = array() ) {

			global $wpdb;

			if ( empty( $row_id_arr ) ) {
				return false;
			}
			$query = 'DELETE FROM ' . CLICKARMOUR_USERS_TABLE . ' WHERE id IN ';

			$values = $row_id_arr;

			$query .= '(' . implode( ', ', array_fill( 0, count( $row_id_arr ), '%d' ) ) . ');';

			$result = $wpdb->query( $wpdb->prepare( $query, $values ) );

			if ( false === $result ) {
				return false;
			}

			return true;
		}




		/**
		 * Delete table
		 *
		 * @since 1.0.0
		 * @return boolean true on success
		 */
		public function delete_table() {
			global $wpdb;
			$result = $wpdb->query( 'DROP TABLE IF EXISTS ' . CLICKARMOUR_USERS_TABLE );
			delete_option( CLICKARMOUR_TABLE_VERSION );
			return $result;
		}

	}

}

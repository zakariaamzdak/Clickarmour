<?php
/**
 * Clickarmour User Class
 *
 * @package Clickarmour
 * @subpackage Clickarm_User
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;


if ( ! class_exists( 'Clickarm_User' ) ) {

	/**
	 * Loads Clickarmour Ordinary User methods
	 *
	 * @package Clickarmour
	 * @since 1.0.0
	 */
	class Clickarm_User {


		/** The value is only initialised in case user is blocked
		 *
		 * @var int
		 * @since 1.0.0
		 */
		public $blocked_user_id;

		/** User's IP address
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $user_ip;

		/** API js script
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $api_js;

		/** User Table Class
		 *
		 * @var User_Table
		 * @since 1.0.0
		 */
		public $user_table;


		/**
		 * Singleton for Clickarm_User Instance
		 *
		 * Ensures that only one instance of Clickarm_User exists in memory at any one time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0.0
		 * @return Clickarm_User
		 */
		public static function instance( ) {

			// Store the instance locally to avoid private static replication.
			static $instance = null;

			if ( null === $instance ) {
				$instance = new Clickarm_User();
				$instance->setup_actions();

				$instance->include_modules();
				$instance->set_user_ip();


			}

			return $instance;
		}



		/** Does nothing
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			// Nothing here.
		}

		/**
		 * Sets the IP of the current user
		 *
		 * @since 1.0.0
		 */
		public function set_user_ip() {
			$this->user_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
			//$this->user_ip ='69.63.181.12';  //Facebook - demo
			/*  
			$ip=[rand(0,256),rand(0,256),rand(0,256),rand(0,256)];
			$this->user_ip = implode('.',$ip);
			debug($this->user_ip); */
		}


		/**
		 * Includes the modules from the includes folder
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function include_modules() {

			require 'class-user-table.php';
			$this->user_table = User_Table::instance();

		}


		/**
		 * Sets up actions
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_actions() {
			add_action( 'template_redirect', array( $this, 'handle_pageviews' ) );

			add_action( 'wp_ajax_nopriv_clickarm_get_ad_replacement', array( $this, 'get_ad_replacement' ) );
			add_action( 'wp_ajax_clickarm_get_ad_replacement', array( $this, 'get_ad_replacement' ) );

			add_action( 'wp_ajax_block_this_ip', array( $this, 'block_this_ip' ) );

			add_action( 'wp_ajax_nopriv_block_this_ip', array( $this, 'block_this_ip' ) );

			add_action( 'wp_ajax_nopriv_log_this_ip', array( $this, 'log_this_ip' ) );
			add_action( 'wp_ajax_log_this_ip', array( $this, 'log_this_ip' ) );

			add_action( 'wp_ajax_nopriv_toggle_debugging', array( $this, 'toggle_debugging' ) );
			add_action( 'wp_ajax_toggle_debugging', array( $this, 'toggle_debugging' ) );


			add_action( 'wp_ajax_unblock_this_ip', array( $this, 'unblock_this_ip' ) );

			add_action( 'wp_ajax_nopriv_unblock_this_ip', array( $this, 'unblock_this_ip' ) );
			
			add_action( 'wp_ajax_get_block_status', array( $this, 'get_block_status' ) );

			add_action( 'wp_ajax_nopriv_get_block_status', array( $this, 'get_block_status' ) );
			
		}



		/**
		 * Logs the ip request.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function log_this_ip() {
			clickarmour_debug( '//--------------------------------------------------------------AJAX-REQ-----------------------------------------------------' );
			clickarmour_debug( ($_REQUEST ?? '') );
			clickarmour_debug( '//----------------------------------------------------------------------------------------------------------------------------' );
		}

		/**
		 * Toggles clickarmour debugging
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function toggle_debugging() {
			$license = trim( get_option( 'clickarm_license_key' ) );
			if(hash('sha256',$license)!==$_REQUEST['token']){
				echo "invalid_token";
				wp_die();
			}
			$r="invalid_request";
			if($_REQUEST['debugging_on']){
				$r=update_option( 'clickarmour_debug','yes' );
			}elseif($_REQUEST['debugging_off']){
				$r=update_option( 'clickarmour_debug','no' );
			}
			var_dump($r);
			echo(CLICKARMOUR_URL."debug.log");
			wp_die();
		}

		/**
		 * Starts output buffering.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function start_output_buffering() {
			ob_start();
		}

		/**
		 * Stops output buffering
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function end_output_buffering() {
			add_action(
				'shutdown',
				function() {
					$final = '';

					// We'll need to get the number of ob levels we're in, so that we can iterate over each, collecting
					// that buffer's output into the final output.
					$levels = ob_get_level();

					for ( $i = 0; $i < $levels; $i++ ) {
						$final .= ob_get_clean();
					}

					// Apply any filters to the final output.
					echo apply_filters( 'final_output', $final );
				},
				0
			);
		}

		/**
		 * Filters ads
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function filter_ads() {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

			add_filter(
				'final_output',
				function(  $original_str ) {

					//Filter adsense code.
					$output = preg_replace( '/[a-z\/:]*pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js/', '#adsbygoogle#',  $original_str );

					//Filter ad inserter code.
					if ( is_plugin_active( 'ad-inserter/ad-inserter.php' ) ) {
    		    		$output=preg_replace('/<script>(.{1,20}ai_front.*ai_insert((?!<\/script>).)*)<\/script>/s','<div id="clickarm-disabled-ai"><!--$1--></div>',$output);
					}
					

					if(!$output){
						$output  =  $original_str ; 
					}

					return $output;
				}
			);
		}

		/**
		 * Unblocks the ip 
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function unblock_this_ip() {
			if ( 'blocked' === $this->user_table->get_block_status( $this->user_ip ) ) {
				$this->user_table->update_block_status( 'unblocked', array( $this->user_ip ) );
				$this->user_table->update( array( 'blocked_reason' => ' ' ), 'ip_addr', array( $this->user_ip ) );
			}
		}
		
		/**
		 * Gets block status of the ip 
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function get_block_status() {
			if ( 'blocked' !== $this->user_table->get_block_status( $this->user_ip ) ) {
				echo "unblocked";
			}else{
			    echo "blocked";
			}
			wp_die();
		}



		/**
		 * Blocks the user from seeing any Ads on the page
		 *
		 * @since 1.0.0
		 * @param string $reason the reason user is being blocked.
		 * @return boolean true on success
		 */
		public function block_user( $reason = ' ', $provider = '', $region = '', $perm_block=false,$ref_name=false ) {
			$user_info = $this->user_table->get_single_row( $this->user_ip );
			if ( ! $user_info ) {

				$result = $this->user_table->insert_blocked_ips( array( $this->user_ip ) );

			} elseif ($perm_block) {

				$result = $this->user_table->update_block_status( 'perm_blocked', array( $this->user_ip ) );

				$reason = 'block count exceeded';

			} else {
				$blocked = $this->user_table->update_block_status( 'blocked', array( $this->user_ip ) );

				$data          = array( 'block_count' => (int) $user_info->block_count + 1 );
				$count_updated = $this->user_table->update( $data, 'ip_addr', array( $this->user_ip ) );

				$result = $data || $count_updated;
			}
			if ( $result ) {
				$this->user_table->update( array( 'blocked_date' => time() ), 'ip_addr', array( $this->user_ip ) );

				if ( false !== strpos( strtolower($reason), 'bot' ) ) {
						$this->user_table->update( array( 'type' => 'bot' ), 'ip_addr', array( $this->user_ip ) );

						$this->user_table->update_block_status( 'perm_blocked', array( $this->user_ip ) );
				}
				$provider = preg_split( '/[,\s]+/', $provider )[0];


				$whois =$provider . ' - ' . $region;

				$this->user_table->update( array( 'region' => $whois ), 'ip_addr', array( $this->user_ip ) );

				// Fill in referred blocking details.
				if ( $ref_name ) {
					$block_data   = $this->user_table->get_single_row( $this->user_ip );
					$blocked_refs = $block_data->blocked_refs && strlen( $block_data->blocked_refs ) > 0 ? json_decode( $block_data->blocked_refs ) : array();
					$blocked_refs = array_merge( $blocked_refs, array( $ref_name ) );
					if ( count( $blocked_refs ) > 5 ) {
						$blocked_refs = array_slice( $blocked_refs, -5, 5 );
					}
					$this->user_table->update( array( 'blocked_refs' => wp_json_encode( $blocked_refs ) ), 'ip_addr', array( $this->user_ip ) );
					$this->user_table->update( array( 'blocked_reason' => 'Visitor blocked from seeing ads on ' . count( $blocked_refs ) . ' referred pages' ), 'ip_addr', array( $this->user_ip ) );

				} else {
					$this->user_table->update( array( 'blocked_reason' => $reason ), 'ip_addr', array( $this->user_ip ) );
				}
			}
			return $result;
		}


		/**
		 * Returns replacements for Ads as set by admin, in case when the Ads are blocked for the user
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function get_ad_replacement() {
			$ad_replacement = get_option( 'clickarmour_ad_replacements' );
			echo $ad_replacement;
			wp_die();

		}


		/**
		 * Blocks the user
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function block_this_ip() {

			$request = $this->sanitize_request( $_POST );
			$this->block_user( $request['reason'], $request['provider'], $request['region'] , ((int)$request['perm_block']===1? true:false), ($request['ref_name']??false));

		
			wp_die();

		}


		/**
		 * Prints api script tag
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function print_api_script() {
			?>
				<script type="text/javascript"><?php echo $this->api_js; ?></script>
			<?php
		}
		/**
		 * Main pageview controller function that handles the api call execution
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function handle_pageviews() {
			 if (! wp_doing_ajax() ) {

				clickarmour_debug( '//--------------------------------------------------------------SERVER-SIDE-----------------------------------------------------' );
				clickarmour_debug( 'HTTP_REFERER=>'.($_SERVER['HTTP_REFERER'] ?? '') );
				clickarmour_debug( 'REMOTE_ADDR=>'.$_SERVER['REMOTE_ADDR'] ?? '' );
				clickarmour_debug( 'REQUEST_URI=>'.$_SERVER['REQUEST_URI']  ?? '' );
				clickarmour_debug( 'HTTP_USER_AGENT=>'.$_SERVER['HTTP_USER_AGENT'] ?? '' );
				clickarmour_debug( '//-------------------------------------------------------------------------------------------------------------------------------' );


				$this->filter_ads();
				$this->start_output_buffering();
				$this->end_output_buffering();
				
                $js = '';
				$public_api_key = $this->get_public_api_key();
				$js            .= "window.PUBLIC_KEY = '$public_api_key';";
		
				$js          .= "var api_url='" . CLICKARMOUR_API_URL . "';";
				$js          .= "var ajax_url='" . admin_url( 'admin-ajax.php' ) . "';";
				$js          .= $this->get_api_pageview_script();
				$this->api_js = $js;

				add_action( 'wp_head', array( $this, 'print_api_script' ), 0 );

			}
		}



		/**
		 * Returns the JS script to make api call during pageview.
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_api_pageview_script() {
			return 'try{function getCookie(e){for(var o=e+"=",r=document.cookie.split(";"),i=0;i<r.length;i++){for(var t=r[i];" "==t.charAt(0);)t=t.substring(1,t.length);if(0==t.indexOf(o))return t.substring(o.length,t.length)}return null}function setCookie(e,o,r){var i,t="";r&&((i=new Date).setTime(i.getTime()+24*r*60*60*1e3),t="; expires="+i.toUTCString()),document.cookie=e+"="+(o||"")+t+"; path=/"}if(window.BLOCK_STATUS=!!getCookie("clickarmour-user-blocked")&&"1","1"===window.BLOCK_STATUS)throw new Error("ClickArmour:User blocked from seeing ads");var refererUrl,siteUrl,siteReferer=document.referrer;function getRefPageviewCookieName(){var e=(e=siteReferer).split("?")[0];return"ref_url_"+btoa(e).trim().replace(/\=/g,"")+"_"+btoa(window.location.origin+window.location.pathname).trim().replace(/\=/g,"")}function getHostname(e){var o=document.createElement("a");return o.href=e,o.hostname}0<siteReferer.length&&(refererUrl=getHostname(siteReferer),siteUrl=getHostname(document.location.href),siteReferer=refererUrl===siteUrl?"":siteReferer);var head,script,pageviewCookieName="total_pageviews",refPageviewCookieName=getRefPageviewCookieName(),params="?action=clickarm_filter&pageviewCookie="+getCookie(pageviewCookieName)+"&refPageviewCookie="+getCookie(refPageviewCookieName)+"&blockCount="+getCookie("clickarmour-user-block-count")+"&referer="+siteReferer+(getCookie("visitorTested")?"&visitorTested="+getCookie("visitorTested"):"")+"&width="+screen.width+"&token="+window.PUBLIC_KEY,domLoadedDate=new Date,domLoadedTime=domLoadedDate.getTime()/1e3;window.refPageviewCookieName=refPageviewCookieName,window.BLOCK_STATUS=!!getCookie("clickarmour_ref_blocked"+refPageviewCookieName)&&"1",!1===window.BLOCK_STATUS&&((script=document.createElement("script")).src=api_url+params,document.querySelector("head").appendChild(script),script.onload=function(){window.onAPISuccess&&window.onAPISuccess()})}catch(e){console.log(e.message)}';
		}



		/**
		 * Sanitizes the request array
		 *
		 * @since 1.0.0
		 * @param array $request GET/POST requests from client.
		 * @return array sanitized array
		 */
		public function sanitize_request( $request ) {
			foreach ( $request as $key => $value ) {
				$request[ $key ] = sanitize_text_field( wp_unslash( $request[ $key ] ) );
			}
			return $request;
		}


		/**
		 * Gets the public api token
		 *
		 * @since 1.0.0
		 * @return string|bool
		 */
		public function get_public_api_key() {
			$public_api_key = get_option( 'clickarmour_public_api_token' );

			if ( $public_api_key && strlen( $public_api_key ) > 5 ) {

				$payload = explode( '.', $public_api_key )[1];

				$payload = json_decode( base64_decode( $payload ), true );

				if ( $payload['exp'] > time() ) {
					return $public_api_key;
				} else {
					$public_api_key = $this->get_new_key_from_server();
					update_option( 'clickarmour_public_api_token', $public_api_key );
					return $public_api_key;
				}
			} else {
				$public_api_key = $this->get_new_key_from_server();
				update_option( 'clickarmour_public_api_token', $public_api_key, 'yes' );

				return $public_api_key;
			}

			return false;
		}

		/**
		 * Gets new key from server
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_new_key_from_server() {

			$urlparts = parse_url( home_url() );
			$domain   = $urlparts['host'];

			$license = trim( get_option( 'clickarm_license_key' ) );

			if ( ! $license || strlen( $license ) < 1 ) {
				return '';
			}
			$license_arr = explode( '_', $license );

			$sub_id = $license_arr[0];

			$license_substr = $license_arr[1];

			$token = hash_hmac( 'sha256', $sub_id, $license_substr );

			$response = wp_remote_get(
				CLICKARMOUR_USER_URL . "?token=$token&subId=$sub_id&domain=$domain",
				array(
					'sslverify' => false,
				)
			);

			 //debug( wp_remote_retrieve_body( $response ) );
			if ( ! is_wp_error( $response ) ) {
				$data = json_decode( wp_remote_retrieve_body( $response ), true );

				return $data['public_key'] ?? '';
			}
			return '';
		}



	}	
}
<?php
/**
 * Clickarmour Admin Class
 *
 * @package Clickarmour
 * @subpackage Clickarm_Admin
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Clickarm_Admin' ) ) {

	/**
	 * Loads Clickarmour Admin methods
	 *
	 * @package Clickarmour
	 * @since 1.0.0
	 */
	class Clickarm_Admin {


		/** The variable is used to hook css and js scripts exclusively to the Clickarmour Admin page.
		 *
		 * @var string
		 */
		public $admin_page_hook;


		/** User class
		 *
		 * @var User
		 */
		public $user;


		/**
		 * Singleton for Clickarm_Admin Instance
		 *
		 * Ensures that only one instance of Clickarm_Admin exists in memory at any one time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0.0
		 * @return Clickarm_Admin
		 */
		public static function instance( ) {

			// Store the instance locally to avoid private static replication.
			static $instance = null;

			if ( null === $instance ) {
				$instance = new Clickarm_Admin();
				$instance->setup_actions();
				$instance->include_modules();

			}

			return $instance;
		}


		/** Gets things started
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			// Nothing here.
		}



		/**
		 * Sets up action hooks
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_actions() {
			add_action( 'admin_menu', array( $this, 'clickarmour_admin_menu_option' ) );

			add_action( 'wp_ajax_clickarm_fetch_ad_replacements', array( $this, 'return_adreplacements' ) );
			add_action( 'wp_ajax_clickarm_update_replacement_code', array( $this, 'update_replacement_code' ) );

		}

		/**
		 * Includes the modules from the includes folder
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function include_modules() {

			require CLICKARMOUR_INCLUDES_PATH . 'user/class-clickarm-user.php';
			$this->user = Clickarm_User::instance( );

		}


		/**
		 * Adds menu option for Clickarmour in WordPress Admin sidebar
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function clickarmour_admin_menu_option() {
			$this->admin_page_hook = add_menu_page(
				'ClickArmour',
				'ClickArmour',
				'manage_options',
				'clickarmour-menu',
				array( $this, 'clickarmour_admin_page' ),
				CLICKARMOUR_INCLUDES_URL."scripts/images/logo.png",
				200
			);

			// Hook to the enqueue functions in scripts file.
			add_action( 'admin_print_styles-' . $this->admin_page_hook,  'clickarm_enqueue_admin_style' );
			add_action( 'admin_print_scripts-' . $this->admin_page_hook,  'clickarm_enqueue_admin_scripts' );
		}



		/**
		 * Includes the html template for admin page
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function clickarmour_admin_page() {
			include_once CLICKARMOUR_PATH . 'templates/admin-panel.php';
		}


		/**
		 * Handles Ajax request for fetching the ad banner replacements
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function return_adreplacements() {
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'fetch-ad-replacement' ) ) {
				echo 'error';
				wp_die();
			}
	

			$ad_replacement = get_option( 'clickarmour_ad_replacements' );
			echo $ad_replacement;
			wp_die();
		}


		/**
		 * Handles Ajax request to update ad replacements
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function update_replacement_code() {

			if ( ! isset( $_POST['replacement_code'] ) || ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'update-ad-replacement' ) ) {
				echo 'error';
				wp_die();
			}

			update_option( 'clickarm_license_key', trim( $_POST['license'] ) );
			$this->update_public_token();
			$ad_replacement = json_decode( wp_unslash( $_POST['replacement_code'] ), true );
			$result = update_option( 'clickarmour_ad_replacements', wp_json_encode( $ad_replacement  ) );

			if ($result ) {
				echo 'success';
				wp_die();
			};
			echo 'failed';
			wp_die();
		}

	
		/**
		 * Updates public token
		 *
		 * @since 1.0.0
		 */
		public function update_public_token() {
			$public_api_key = $this->user->get_new_key_from_server();
			update_option( 'clickarmour_public_api_token', $public_api_key, 'yes' );
			
		}

	}
}

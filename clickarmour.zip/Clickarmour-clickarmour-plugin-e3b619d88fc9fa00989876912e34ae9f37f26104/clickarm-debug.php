<?php

    
if(! function_exists('clickarmour_debug') ){
    function clickarmour_debug( $object ) {
        if('yes'===get_option('clickarmour_debug')){
            if (session_id() == ""){
                try {
                    session_start();
                } catch (Exception $e) {
                }
            }
            $object  = session_id().':'.date( 'm/d/Y h:i:s a', time() ) . ':' . ( json_encode( $object, JSON_PRETTY_PRINT ) );
            $object .= "\n";
            error_log( $object, 3, CLICKARMOUR_PATH . '/debug.log' );
            return;
        }

    }
}

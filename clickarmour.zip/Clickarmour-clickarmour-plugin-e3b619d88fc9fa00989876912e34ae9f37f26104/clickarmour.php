<?php
/**
 * The Clickarmour Plugin
 *
 * @package Clickarmour
 */

/**
 * Plugin Name:         Clickarmour
 * Description:         Clickarmour is a plugin to monitor and protect your Adsense from malicious activity.
 * Version:             2.2.3
 * Author:              Clickarmour
 * Author URI:          https://www.clickarmour.com
 * Disclaimer:          Use at your own risk. No warranty expressed or implied is provided.
 * Text Domain:         Clickarmour
 * Requires PHP:        5.6.20
 * License:             GPLv2 or later(license.txt)
 */


/** Developer note: To undertstand better how this plugin works,
 *  please first go through the feature list and properly understand it's purpose for existence.
 */


// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

global $wpdb;

/**
 * The name of the user database table
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_USERS_TABLE' ) || define( 'CLICKARMOUR_USERS_TABLE', $wpdb->prefix . 'clickarmour_users' );


/**
 * The version of Clickarmour
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_VERSION' ) || define( 'CLICKARMOUR_VERSION', '1.8' );



/**
 * The Clickarmour API URL
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_API_URL' ) || define( 'CLICKARMOUR_API_URL', 'https://api.clickarmour.com/api' );


/**
 * The Clickarmour API URL
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_USER_URL' ) || define( 'CLICKARMOUR_USER_URL', 'https://api.clickarmour.com/user/get-token' );


/**
 * The version of our database table
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_TABLE_VERSION' ) || define( 'CLICKARMOUR_TABLE_VERSION', '1.0.0' );

/**
 * The version of our database table
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_REST_VERSION' ) || define( 'CLICKARMOUR_REST_VERSION', '1.0.0' );

/**
 * The path of the main plugin file
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_PLUGIN_PATH' ) || define( 'CLICKARMOUR_PLUGIN_PATH', __FILE__ );


/**
 * The path of the plugin folder
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_PATH' ) || define( 'CLICKARMOUR_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );



/**
 * The url of the plugin folder
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_URL' ) || define( 'CLICKARMOUR_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );


/**
 * The path of the includes folder
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_INCLUDES_PATH' ) || define( 'CLICKARMOUR_INCLUDES_PATH', CLICKARMOUR_PATH . 'includes/' );

/**
 * The url of includes folder
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_INCLUDES_URL' ) || define( 'CLICKARMOUR_INCLUDES_URL', CLICKARMOUR_URL . 'includes/' );


/**
 * The url for plugin updates
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_UPDATES_INFO_URL' ) || define( 'CLICKARMOUR_UPDATES_INFO_URL', 'https://server.clickarmour.com/wp-json/clickarm/v1/clickarmour-updates/' );

/**
 * The url for plugin download
 *
 * @var string
 * @since 1.0.0
 */
defined( 'CLICKARMOUR_DOWNLOAD_URL' ) || define( 'CLICKARMOUR_DOWNLOAD_URL', 'https://server.clickarmour.com/wp-json/clickarm/v1/clickarmour-download/' );

/**
 * Cookie to ensure that cached content with ads is not served to bots for clients having wp rocket.
 *
 * @var string
 * @since 1.0.0
 */
define( 'WPROCKETHELPERS_CACHE_MANDATORY_COOKIE', 'clickarmour-bot-filter' );



// Debugger function to log errors.
 require_once CLICKARMOUR_PATH . 'clickarm-debug.php';

// Main Clickarmour class.
require_once CLICKARMOUR_PATH . 'class-clickarmour.php';


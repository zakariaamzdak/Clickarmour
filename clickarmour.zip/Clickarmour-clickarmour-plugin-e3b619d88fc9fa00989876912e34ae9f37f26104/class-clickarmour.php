<?php
/**
 * The Clickarmour main class
 *
 * @package Clickarmour
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;


if ( ! class_exists( 'Clickarmour' ) ) {

	/**
	 * Main Clickarmour class
	 *
	 * It is a mistake to think you can solve any major problems just with potatoes.
	 *
	 * @since 1.0.0 Clickarmour
	 */
	final class Clickarmour {


		/** User class
		 *
		 * @var User
		 */
		public $user;


		/** User_Table class
		 *
		 * @var User_Table
		 */
		public $user_table;


		/** License key`
		 *
		 * @var string
		 */
		private $license_key;


		/**
		 * Singleton for main Clickarmour Instance
		 *
		 * Ensures that only one instance of Clickarmour exists in memory at any one time. Also prevents needing to define globals allover the place.
		 *
		 * @since 1.0.0
		 * @return Clickarmour The one true Clickarmour
		 */
		public static function instance() {

			// Store the instance locally to avoid private static replication.
			static $instance = null;

			if ( null === $instance ) {
				$instance = new Clickarmour();
				$instance->setup_hooks();

				$instance->setup_variables();
				$instance->include_modules();

			}

			return $instance;
		}




		/** Gets things started
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			// Nothing here.
		}

		/**
		 * Sets up the action hooks, registration hooks and filter.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_hooks() {
			register_activation_hook( CLICKARMOUR_PLUGIN_PATH, array( $this, 'activate_plugin_networkwide' ) );
			//register_deactivation_hook( CLICKARMOUR_PLUGIN_PATH, array( $this, 'uninstall_plugin' ) );
		}


		/**
		 * Includes the modules from the includes folder
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function include_modules() {

			require_once CLICKARMOUR_INCLUDES_PATH . 'updater/class-clickarm-updater.php';
			$updater = Clickarm_Updater::instance();
			$updater->initialize();
			require CLICKARMOUR_INCLUDES_PATH . 'user/class-user-table.php';
			$this->user_table = User_Table::instance();

			require CLICKARMOUR_INCLUDES_PATH . 'rest/class-clickarm-rest-controller.php';
			$this->rest_controller = Clickarm_REST_Controller::instance($this->license_key );

			require CLICKARMOUR_INCLUDES_PATH . 'user/class-clickarm-user.php';
			$this->user = Clickarm_User::instance();

			if ( is_admin() ) {
				require CLICKARMOUR_INCLUDES_PATH . 'admin/class-clickarm-admin.php';
				$this->admin = Clickarm_Admin::instance();
			}
			require CLICKARMOUR_INCLUDES_PATH . 'scripts/scripts.php';

		}


		/**
		 * Sets up the varibles uses by Clickarmour class
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_variables() {
			$this->license_key = get_option( 'clickarm_license_key' );
			if ( $this->license_key || strlen( $this->license_key ) < 1 ) {
				add_option( 'clickarm_license_key', '  ' );
			}

		}


		/**
		 * Creates plugin table for each blog(in case it is multisite) and unzips the ip2proxy DB on activation
		 *
		 * @since 1.0.0
		 * @param bool $networkwide indicates if the plugin is being activated network-wide.
		 * @return void
		 */
		public function activate_plugin_networkwide( $networkwide ) {

			global $wpdb;
			if ( function_exists( 'is_multisite' ) && is_multisite() ) {
				if ( $networkwide ) {
							$old_blog = $wpdb->blogid;
					$blogids          = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
					foreach ( $blogids as $blog_id ) {
						switch_to_blog( $blog_id );
						$this->activate_plugin();
					}
					switch_to_blog( $old_blog );
					return;
				}
			}

			$this->activate_plugin();

		}

		/**
		 * Activates the plugin for all the individual blogs if it is a multisite
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function activate_plugin() {
			global $wpdb;
		;
			$this->user_table->create_table( CLICKARMOUR_USERS_TABLE );
		}


		/**
		 * Perform certain tasks when the plugin is uninstalled
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function uninstall_plugin() {

			$this->user_table->delete_table();
		}



		/**
		 * Executes in the case an admin visits the site
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function run_admin_routine() {

		}


		/**
		 * Sets up the admin notices and displays them
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function execute_admin_notices() {

		}

		/**
		 * Setups the language domain
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_lanuage_domain() {

		}


		/**
		 * Check license
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function check_license() {

		}


		/**
		 * Decrypts the settings stored in DB
		 *
		 * @since 1.0.0
		 * @param string $license_key license key for the domain.
		 * @param string $encrypted_settings admin settings from the DB.
		 */
		public function decrypt_settings( $license_key, $encrypted_settings ) {

		}
	}

	$clickarmour = Clickarmour::instance();

}

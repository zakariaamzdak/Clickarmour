<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<div id="clickarmour-admin">
    <div class="row carm-heading align-items-center">
      
        <div class="col-6 ">
             <img src="<?php echo(CLICKARMOUR_INCLUDES_URL."scripts/images/clickarmour.png");?>"></img>

        </div>
	
        <div class="col-6 text-right">
            <a href="https://dashboard.clickarmour.com/" target="_blank" class="ml-3"> 
    		    <button type="button" class="btn btn-primary carm-btn">Go to dashboard</button>
    	    </a>
			<!-- <a class="ml-2"> 
    		    <button type="button" class="btn btn-primary carm-btn update-token">Update public token</button>
    	    </a> -->
    	 </div>

    </div>
 
    <div class='spinner' id="clickarm-spinner"></div> 
	<ul class="nav nav-tabs" id="clickArmour-tab" role="tablist">
		<li class="nav-item">
		   <a class="nav-link active" id="license-tab" data-toggle="tab" href="#license" role="tab" aria-controls="license" aria-selected="true">License Configuration</a>

		   <div class="clickarm-flying-bar"></div>
		</li>
		<li class="nav-item">
			<a class="nav-link" id="clickarm-ad-replace-tab" data-toggle="tab" href="#ad-replace" role="tab" aria-controls="ad-replace" aria-selected="false">Ad replacement</a>
		</li>
	</ul>

	<div class="tab-content" id="clickarmour-content">

		<div class="tab-pane fade show active" id="license" role="tabpanel" aria-labelledby="license-tab">
			<div class="form-group row">
				<label for="inputEmail3" class="col-sm-4 col-form-label">License Key</label>
				<div class="col-sm-8">
				  <input type="text" class="form-control" id="inputEmail3" placeholder="Enter the license key that you received.">
				</div>
			</div>
		</div>

		<div class="tab-pane fade" id="ad-replace"" role="tabpanel" aria-labelledby="ad-replace-tab">
		  <div class="form-group row">
			  <div class="col-sm-4">
				<div class="row"> 
					<div class="col-sm-10 col-12">
						<input type="text" class="form-control" id="clickarm-banner-name" placeholder="Enter Ad Banner name">
						<button type="button" id="clickarm-add-banner" class="col-12 mt-2 btn btn-primary carm-btn">Add banner to list below</button>

					</div>
				</div>
				<div class="row mt-5">
					<div class="col-sm-10 col-12">
						
						<select class="selectpicker" id="clickarm-select" title="Select Ad banners" multiple>
								<?php
								$ad_replacements = get_option('clickarmour_ad_replacements' );
								if ( $ad_replacements) {
									$ad_replacements = json_decode($ad_replacements);
									foreach ( $ad_replacements as $banner_name => $code ) {
										echo '<option>' . esc_html( $banner_name ) . '</option>';
									};
								}

								?>
						</select>
						<button type="button" id="clickarm-remove-selected" class="col-12 mt-2 btn btn-primary carm-btn">Remove selected</button>

					</div>
				</div>
			  </div>
			  <div class="col-sm-8">
				  <textarea class="form-control" id="clickarm-replacement-code" rows="5" placeholder="Enter replacement code for selected Ad Banners"></textarea>
						<hr class="mb-2 mt-4">
						<p class="text-center mt-0 mb-0">Or</p>
						<small class="clickarm-error">Please provide link of the image!</small> 
					<input type="text" class="form-control mt-2" id="clickarm-img-url" placeholder="Enter link of the image to be used as replacement">

					<div class="row">
						<div class="col-sm-8">
							<input type="text" class="form-control mt-4" id="clickarm-redirect-url" placeholder="Enter redirect url when user clicks on image">
						</div>
						<div class="col-sm-4">
							<input type="text" class="form-control mt-4" id="clickarm-img-height" placeholder="Image height in pixels">
						</div>
					</div>
					<div class="mt-4 d-flex justify-content-end">
						<button type="button" id="clickarm-generate-code"class="btn btn-primary carm-btn">Generate code</button>
					</div>
				</div>
		  </div>

		</div>

	</div>
	<div class="form-group row">
		<div class="col-sm-8 ">
		  <button type="submit" id="clickarm-save" class="btn btn-primary carm-btn">Save</button>
		</div>
	</div>
	<div class="row">
	    <div class="col-12 text-center">
	        <small>Copyright © ClickArmour 2021.</small>
	    </div>
	</div>
</div>
